/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exxmldocenti;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

/**
 *
 * @author trezzi_luca
 */
public class EXXMLDocenti {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, ParserConfigurationException, SAXException {
        // TODO code application logic here
        List<docente> docenti = null;
        Parser dom = new Parser();
        myFile mioF = new myFile();
        docenti = dom.parseDocument("ricevimento.xml");
        BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
        boolean fine = false;
        String scelta = "";
        while (!fine) {
            System.out.println("1)ricerca per giorno 2)ricerca per docente 3)visualizza docenti 0)esci");
            scelta = inFromUser.readLine();
            switch (scelta) {
                case "1":

                    System.out.println("Inserire giorno");
                    String giorno = inFromUser.readLine();
                    giorno = giorno.replaceAll("i", "ì");
                    for (docente d : docenti) {
                        if (giorno.equals(d.getGiorno())) {
                            System.out.println(d.toString());
                            mioF.SalvaSuFile(d.toString());
                        }
                    }
                    break;
                case "2":
                    System.out.println("Inserire docente");
                    String nome = inFromUser.readLine();
                    for (docente d : docenti) {
                        if (nome.equals(d.getDocente())) {
                            System.out.println(d.toString());
                            mioF.SalvaSuFile(d.toString());
                        }
                    }
                    break;
                case "3":
                    for (docente d : docenti) {
                        System.out.println(d.toString());
                    }
                    break;
                case "0":
                    fine = true;
                    break;
            }
        }
    }

}
